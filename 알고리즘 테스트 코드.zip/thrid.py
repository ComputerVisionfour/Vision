# -*- coding: utf-8 -*-
"""
Created on Thu Oct 21 13:13:44 2021

@author: Coding
"""

import cv2

img_color = cv2.imread('pop_ref_001.jpg', cv2.IMREAD_COLOR)
src = cv2.resize(img_color, dsize=(640, 480), interpolation=cv2.INTER_AREA)
dst = src.copy()
gray = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY)

circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1, 100, param1 = 250, param2 = 10, minRadius = 80, maxRadius = 120)

for i in circles[0]:
    cv2.circle(dst, (i[0], i[1]), i[2], (255, 255, 255), 5)

cv2.imshow("dst", dst)
cv2.waitKey(0)
cv2.destroyAllWindows()